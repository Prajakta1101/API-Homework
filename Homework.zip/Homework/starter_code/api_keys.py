# OpenWeatherMap API Key
weather_api_key = "3af568ae85007761b4cb3dc238d425ef"

# Google API Key
g_key = "AIzaSyB-qirhF5ZQymId1xNs_5fpL6xYnKm0JHU"
